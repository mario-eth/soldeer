var convert = require('./convert'),
    func = convert('updateWith', require('../updateWith'));

func.placeholder = require('./placeholder');
module.exports = func;
