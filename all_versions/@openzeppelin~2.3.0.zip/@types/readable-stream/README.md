# Installation
> `npm install --save @types/readable-stream`

# Summary
This package contains type definitions for readable-stream (https://github.com/nodejs/readable-stream).

# Details
Files were exported from https://github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/readable-stream.

### Additional Details
 * Last updated: Mon, 31 Oct 2022 08:03:03 GMT
 * Dependencies: [@types/node](https://npmjs.com/package/@types/node), [@types/safe-buffer](https://npmjs.com/package/@types/safe-buffer)
 * Global values: `_Readable`

# Credits
These definitions were written by [TeamworkGuy2](https://github.com/TeamworkGuy2), and [markdreyer](https://github.com/markdreyer).
